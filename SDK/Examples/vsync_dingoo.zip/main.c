// -------------------------------------------------------
// Test for VSYNC display
// Written Franck "hitchhikr Charlet.
// -------------------------------------------------------

// -------------------------------------------------------
// Includes
#include <stdlib.h>
#include "vsync_display.h"

// -------------------------------------------------------
// Variables
DISPLAY MainDisplay __attribute__((aligned(256)));

// -------------------------------------------------------
// Remove all interrupts
void cli(void)
{
    write_c0_status(read_c0_status() & ~1);
}

// -------------------------------------------------------
// Restore all interrupts
void sti(void)
{
    write_c0_status(read_c0_status() | 1);
}

// -------------------------------------------------------
// Display a moving vertical bar
void display_bar(LPDISPLAY Display, int32_t Pos)
{
    register int32_t i;
    register int32_t j;
    register int32_t inColor;
    register int8_t R = 0xff;
    register int8_t B = 0;

    if(Display->tvout)
    {
        // Output is 16 bit
        uint16_t *tempLineStart;
        uint16_t *tempLineStartL = Display->back_buffer + Pos;
        for(j = 0; j < Display->height; j++)
        {
            inColor = rgb_to_16(R, B, B);
    	    tempLineStart = tempLineStartL;
            for(i = 0; i < 32; i++)
            {
        		*tempLineStart++ = (inColor << 16) | inColor;
            }
    	    tempLineStartL = tempLineStartL + Display->width;
            B++;
            R--;
    	}
    }
    else
    {
        // Output is padded to 32 bit and rotated in LCD mode
        uint32_t *tempLineStart;
        uint32_t *tempLineStartL = ((uint32_t *) Display->back_buffer) + (Pos * Display->height);
        for(j = 0; j < Display->height; j++)
        {
            inColor = rgb_to_16(R, B, B);
    	    tempLineStart = tempLineStartL;
            for(i = 0; i < 32; i++)
            {
        		tempLineStart[i * Display->height] = (inColor << 16) | inColor;
            }
    	    tempLineStartL++;
            B++;
            R--;
    	}
    }
}

// -------------------------------------------------------
// Program entry point
int main(int argc, char *argv[])
{
    register int32_t pos_bar = 0;
    register int32_t way_bar = 0;

    cli();
	control_init();
	control_lock(timer_resolution / 4);

    create_display(&MainDisplay, 1);

    // ----------------------------------------
    // Main loop
    while(1)
    {
	    if(flip_display(&MainDisplay, 1))
	    {
            // ----------------------------------------
            // Just a test
            clear_screen(&MainDisplay, 0, 0, 0);
            if(way_bar)
            {
                pos_bar -= 2;
                if(pos_bar <= 0)
                {
                    pos_bar = 0;
                    way_bar = 0;
                }
            }
            else
            {
                pos_bar += 2;
                if(pos_bar >= 320 - 33)
                {
                    pos_bar = 320 - 33;
                    way_bar = 1;
                }
            }
            display_bar(&MainDisplay, pos_bar);
            // ----------------------------------------

            _dcache_writeback_all();
            ack_display();
        }

    	if(_sys_judge_event(NULL) < 0) break;
		control_poll();
		if(control_check(CONTROL_BUTTON_START).pressed &&
           control_check(CONTROL_BUTTON_START).changed)
		{
			break;
		}
		OSTimeDly(1);
    }

	control_term();
	destroy_display(&MainDisplay);
    sti();
    return EXIT_SUCCESS;
}
