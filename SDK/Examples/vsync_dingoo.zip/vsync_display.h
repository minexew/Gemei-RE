// -------------------------------------------------------
// Perfect VSYNC for the DINGOO A320 console
// Written Franck "hitchhikr Charlet.
// -------------------------------------------------------

// -------------------------------------------------------
// Includes
#include <dingoo/slcd.h>
#include <sml/graphics.h>
#include <sml/display.h>
#include <sml/control.h>
#include <sml/timer.h>
#include <dingoo/jz4740.h>
#include <dingoo/cache.h>
#include <dingoo/time.h>
#include <asm-mips/mipsregs.h>

// -------------------------------------------------------
// Structures
struct lcd_desc
{
	uint32_t next;
	uint32_t buf;
	uint32_t id;
	uint32_t cmd;
};

typedef struct
{
    struct lcd_desc lcd_frame_desc;
	int width;
	int height;
	int tvout;
	int Frequency;
	uint32_t LCD_Type;
	uint32_t Old_DAO;
	uint32_t Old_VAT;
	uint32_t Old_DAH;
	uint32_t Old_DAV;
	uint32_t Old_HSYNC;
	uint32_t Old_VSYNC;
	uint32_t Old_CPM_CPCCR;
	uint32_t Old_CPM_LPCDR;
	uint32_t Old_CPM_CPPCR;
	uint16_t *front_buffer;
	uint16_t *back_buffer;
} DISPLAY, *LPDISPLAY;


void clear_screen(LPDISPLAY Display, uint8_t R, uint8_t G, uint8_t B);
void destroy_display(LPDISPLAY Display);
int flip_display(LPDISPLAY Display, int Wait_VSync);
void create_display(LPDISPLAY Display, int Fix_PAL_NTSC);
void ack_display();
