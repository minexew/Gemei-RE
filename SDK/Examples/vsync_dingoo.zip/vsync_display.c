// -------------------------------------------------------
// VSYNC display for the DINGOO A320 console
// Written Franck "hitchhikr Charlet.
// -------------------------------------------------------

// -------------------------------------------------------
// Includes
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <dingoo/slcd.h>
#include <sml/graphics.h>
#include <sml/display.h>
#include <sml/control.h>
#include <sml/timer.h>
#include <dingoo/jz4740.h>
#include <dingoo/cache.h>
#include <dingoo/time.h>
#include <asm-mips/mipsregs.h>

// -------------------------------------------------------
// Constants
#define CFG_EXTAL 12000000          /* EXTAL freq: 12 MHz */
#define PIN_RS_N (32 * 2 + 19)
#define PIN_CS_N (32 * 1 + 17)
#define PIN_RESET_N (32 * 1 + 18)

#define __slcd_special_rs_enable() \
do { \
    __gpio_clear_pin(PIN_RS_N); \
} while(0)

#define __slcd_special_rs_disable() \
do { \
    __gpio_set_pin(PIN_RS_N); \
} while(0)

// -------------------------------------------------------
// Structures
struct lcd_desc
{
	uint32_t next;
	uint32_t buf;
	uint32_t id;
	uint32_t cmd;
};

typedef struct
{
    struct lcd_desc lcd_frame_desc;
	int width;
	int height;
	int tvout;
	int Frequency;
	uint32_t LCD_Type;
	uint32_t Old_DAO;
	uint32_t Old_VAT;
	uint32_t Old_DAH;
	uint32_t Old_DAV;
	uint32_t Old_HSYNC;
	uint32_t Old_VSYNC;
	uint32_t Old_CPM_CPCCR;
	uint32_t Old_CPM_LPCDR;
	uint32_t Old_CPM_CPPCR;
	uint16_t *front_buffer;
	uint16_t *back_buffer;
} DISPLAY, *LPDISPLAY;

typedef struct
{
    uint32_t size;          // 0   248
    char Type[4];           // 4   "GFC."
    uint8_t unk0[12];       // 8   Unknown data (maybe chinese string ?)
    uint32_t unk1;          // 20  0
    uint32_t unk2;          // 24  123
    uint32_t unk3;          // 28  1
    uint8_t  unk4;          // 32  0
    char Firmware[19];      // 33  "A320.HXF"
    uint32_t unk5;          // 52  1
    uint32_t width;         // 56  320
    uint32_t height;        // 60  240
    uint32_t bpp;           // 64  16
    uint32_t unk6;          // 68  0
    char ScreenName[32];    // 72
    uint8_t unk7;           // 104 1
    uint8_t unk8[15];       // 105 0
    uint8_t unk9;           // 120 1
    uint8_t pad[127];       // 121 0
} CCPMP_CONFIG, *LPCCPMP_CONFIG;

// -------------------------------------------------------
// Variables
DISPLAY MainDisplay __attribute__((aligned(256)));
uint16_t display_front_buf[640 * 240] __attribute__((aligned(256)));
uint16_t display_back_buf[640 * 240] __attribute__((aligned(256)));

// -------------------------------------------------------
// Wait for a given number of milliseconds
void sleep(int32_t ms)
{
    int32_t i;

    __tcu_disable_pwm_output(3);
    __tcu_mask_half_match_irq(3);
    __tcu_mask_full_match_irq(3);
    __tcu_select_extalclk(3);
    __tcu_select_clk_div16(3);
    REG_TCU_TDFR(3) = CFG_EXTAL / 16 / 1000;
    REG_TCU_TDHR(3) = CFG_EXTAL / 16 / 1000;
    __tcu_set_count(3, 0);
    __tcu_start_counter(3);
    for(i = 0; i < ms; i++)
    {
        __tcu_clear_full_match_flag(3);
        while(!__tcu_full_match_flag(3));
    }
    __tcu_stop_counter(3);
}

// -------------------------------------------------------
// Send a command to the LCD
void LCD_Command(uint32_t cmd)
{
	__slcd_special_rs_enable();
    REG_SLCD_DATA = SLCD_DATA_RS_COMMAND | (cmd & 0xffff);
    while(REG_SLCD_STATE & SLCD_STATE_BUSY);
    __slcd_special_rs_disable();
}

// -------------------------------------------------------
// Send command's data to the LCD
void LCD_RegSet(uint32_t cmd, uint32_t data)
{
    __lcd_as_smart_lcd();
    REG_SLCD_DATA = SLCD_DATA_RS_DATA;
    while(REG_SLCD_STATE & SLCD_STATE_BUSY);
    LCD_Command(cmd);
    REG_SLCD_DATA = SLCD_DATA_RS_DATA | (data & 0xffff);
    while(REG_SLCD_STATE & SLCD_STATE_BUSY);
    LCD_Command(0x20);
    REG_SLCD_DATA = SLCD_DATA_RS_DATA;
    while(REG_SLCD_STATE & SLCD_STATE_BUSY);
    LCD_Command(0x21);
    REG_SLCD_DATA = SLCD_DATA_RS_DATA;
    while(REG_SLCD_STATE & SLCD_STATE_BUSY);
    LCD_Command(0x22);
    __lcd_as_general_lcd();
}

// -------------------------------------------------------
// Convert a given RGB color to 16 bits
inline gfx_color rgb_to_16(uint8_t R, uint8_t G, uint8_t B)
{
    return((R & 0xf8) << 8) |
          ((G & 0xfc) << 3) |
          ((B & 0xf8) >> 3);
}

// -------------------------------------------------------
// Clear the entire screen with a given color
void clear_screen(LPDISPLAY Display, uint8_t R, uint8_t G, uint8_t B)
{
    int32_t i;
    int32_t j;
    gfx_color inColor = rgb_to_16(R, G, B);

    if(Display->tvout)
    {
	    uint16_t *tempLineStart = Display->back_buffer;
        for(j = 0; j < Display->height; j++)
        {
            for(i = 0; i < Display->width; i++)
            {
        		*tempLineStart++ = (inColor << 16) | inColor;
            }
	    }
    }
    else
    {
	    uint32_t *tempLineStart = (uint32_t *) Display->back_buffer;
        for(j = 0; j < Display->height; j++)
        {
            for(i = 0; i < Display->width; i++)
            {
        		*tempLineStart++ = (inColor << 16) | inColor;
            }
	    }
    }
}

// -------------------------------------------------------
// Restore the original context
void destroy_display(LPDISPLAY Display)
{
    __lcd_as_general_lcd();
    REG_LCD_DA0 = Display->Old_DAO;
	REG_LCD_VAT = Display->Old_VAT;
	REG_LCD_DAH = Display->Old_DAH;
	REG_LCD_DAV = Display->Old_DAV;
	REG_LCD_HSYNC = Display->Old_HSYNC;
	REG_LCD_VSYNC = Display->Old_VSYNC;
    REG_CPM_CPCCR = Display->Old_CPM_CPCCR;
    REG_CPM_LPCDR = Display->Old_CPM_LPCDR;
    REG_CPM_CPPCR = Display->Old_CPM_CPPCR;

	if(!Display->tvout)
	{
	    // Restore (guessed) default values
	    LCD_RegSet(0x2b, 0xd);
	    LCD_RegSet(0xc, 0);
	    LCD_RegSet(0x2, 0);
	    LCD_RegSet(0x8, 0x808);
	    LCD_RegSet(0x3, 0x1048);
        __lcd_as_smart_lcd();
    }
}

// -------------------------------------------------------
// Wait for vblank and switch buffers
int flip_display(LPDISPLAY Display, int Wait_VSync)
{
    if(REG_LCD_STATE & LCD_STATE_EOF)
	{
        register uint16_t *swap_buf = Display->back_buffer;
        Display->back_buffer = Display->front_buffer;
        Display->front_buffer = swap_buf;
        Display->lcd_frame_desc.buf = ((uint32_t) Display->back_buffer) & 0x7fffffff;
        return 1;
    }
    else
    {
        return 0;
    }
}

// -------------------------------------------------------
// Start a new transfer
void ack_display()
{
    __lcd_clr_eof();
}

// -------------------------------------------------------
// Create the display context
void create_display(LPDISPLAY Display, int Fix_PAL_NTSC)
{
    uint32_t val;
    uint32_t pclk;
	int32_t pll_div;
	int i;
	register int32_t In_TvOut = 1;

    // We're coming from the OS so if it's using the not-so-smart LCD controller
    // we know the show isn't running on TV.
    if(REG_LCD_CFG & LCD_CFG_LCDPIN_SLCD) In_TvOut = 0;

	Display->LCD_Type = 0x9325;
    // Determine the type of the LCD by looking for the string "ILI9331"
    // in the "ccmp.cfg" config, if it can't be found then it's (hopefully) a ILI9325
    LPCCPMP_CONFIG Config = (LPCCPMP_CONFIG) sys_get_ccpmp_config();
    for(i = 0; i < 32; i++)
    {
        if(strncmp(&Config->ScreenName[i], "ILI9331", 7) == 0)
        {
            Display->LCD_Type = 0x9331;
            break;
        }
    }
	Display->width = 320;
	Display->height = 240;
	Display->tvout = In_TvOut;
	Display->front_buffer = display_front_buf;
	Display->back_buffer = display_back_buf;
	__lcd_set_dis();
    __lcd_clr_ena();
    memset(display_front_buf, 0, sizeof(display_front_buf));
    memset(display_back_buf, 0, sizeof(display_back_buf));
	Display->lcd_frame_desc.next = ((uint32_t) &Display->lcd_frame_desc) & 0x7fffffff;
	Display->lcd_frame_desc.buf = ((uint32_t) Display->back_buffer) & 0x7fffffff;
	Display->lcd_frame_desc.id = 0xdeafbeef;
	Display->lcd_frame_desc.cmd = LCD_CMD_EOFINT |
	                              (((In_TvOut ? Display->width : Display->width * 2) * Display->height) >> 1);
	Display->Old_VAT = REG_LCD_VAT;
	Display->Old_DAH = REG_LCD_DAH;
	Display->Old_DAV = REG_LCD_DAV;
	Display->Old_HSYNC = REG_LCD_HSYNC;
	Display->Old_VSYNC = REG_LCD_VSYNC;
	Display->Old_CPM_CPCCR = REG_CPM_CPCCR;
	Display->Old_CPM_LPCDR = REG_CPM_LPCDR;
    Display->Old_CPM_CPPCR = REG_CPM_CPPCR;
    Display->Old_DAO = REG_LCD_DA0;
    _dcache_writeback_all();
    if(In_TvOut)
    {
        // On my TV screen the output is slightly shifted to the left in both NTSC & PAL
        // when using the OS settings, i don't know if it's me or them.
        if(REG_LCD_HSYNC == 60)
        {
            if(Fix_PAL_NTSC)
            {
                // Fix NTSC
                REG_LCD_VAT = (736 << 16) | 272;
                REG_LCD_DAH = (411 << 16) | 731;            // w=320
                REG_LCD_DAV = (29 << 16) | 269;             // h=240
                REG_LCD_HSYNC = (0 << 16) | 60;
                REG_LCD_VSYNC = (0 << 16) | 10;
            }
            Display->Frequency = 60;
        }
        else
        {
            if(Fix_PAL_NTSC)
            {
                // Fix PAL
                REG_LCD_VAT = (876 << 16) | 274;
                REG_LCD_DAH = (552 << 16) | 872;            // w=320
                REG_LCD_DAV = (27 << 16) | 267;             // h=240
                REG_LCD_HSYNC = (0 << 16) | 50;             // Firmware uses 125 but why ?
                REG_LCD_VSYNC = (0 << 16) | 10;
            }
            Display->Frequency = 50;
        }
    }
    else
    {
        LCD_RegSet(0xc, 0x11);
	    LCD_RegSet(0x2b, 0xb);
	    LCD_RegSet(0, 1);
	    LCD_RegSet(0x1, 0);
	    LCD_RegSet(0x2, 0x200);
	    LCD_RegSet(0x50, 0);
	    LCD_RegSet(0x51, 239);
	    LCD_RegSet(0x52, 0);
	    LCD_RegSet(0x53, 319);
	    LCD_RegSet(0x3, 0x200 | 0x20 | 0x1000);
	    LCD_RegSet(0xc, 1);
	    // Adjust the frequency to 51hz (0x4 on the 9325) / (0x8 on the 9331)
        // Common frequencies between the 2 LCD types are: 40(0/5) 43(1/6) 51(4/8) 70(8/b)
        if(Display->LCD_Type == 0x9325) LCD_RegSet(0x2b, 0x4);
        else LCD_RegSet(0x2b, 0x8);
	    LCD_RegSet(0x8, 0x808);
        REG_LCD_CTRL = LCD_CTRL_BPP_16 | LCD_CTRL_RGB565;
        REG_LCD_CFG = LCD_CFG_MODE_GENERIC_TFT | LCD_CFG_VSP | LCD_CFG_HSP | LCD_CFG_PSP;
        __cpm_stop_lcd();
        REG_CPM_CPCCR = 0x40422220;
        REG_CPM_CPCCR &= ~(CPM_CPCCR_I2CS | CPM_CPCCR_PCS | CPM_CPCCR_UCS |
                           CPM_CPCCR_UDIV_MASK |
                           CPM_CPCCR_LDIV_MASK
                          );
        REG_CPM_CPPCR = ((364 - 2) << CPM_CPPCR_PLLM_BIT) |     // PLLM + 2 
                        ((6 - 2) << CPM_CPPCR_PLLN_BIT) |       // PLLN + 2
                        (1 << CPM_CPPCR_PLLOD_BIT) |            // / 2
                        CPM_CPPCR_PLLS |
                        CPM_CPPCR_PLLEN |
                        (1 << CPM_CPPCR_PLLST_BIT);
        // CLKOUT = XIN * (M / N) * (1 / NO)
        // LPCLK (Divider for pixel clock)
        REG_CPM_LPCDR = 22;
        // LDCLK (Divider for device clock)
        REG_CPM_CPCCR |= CPM_CPCCR_CE;// | (0 << CPM_CPCCR_LDIV_BIT);
        __cpm_start_lcd();
        sleep(100);
        REG_LCD_VAT = (1 << 16) | 2;
        REG_LCD_DAH = (0 << 16) | 1;
        REG_LCD_DAV = (0 << 16) | 1;
        REG_LCD_HSYNC = (0 << 16) | 1;
        REG_LCD_VSYNC = (0 << 16) | 1;
        Display->Frequency = 50;
    }
    _dcache_writeback_all();
    REG_LCD_DA0 = ((uint32_t) &Display->lcd_frame_desc) & 0x7fffffff;
	__lcd_clr_dis();
    __lcd_set_ena();
}
