/***************************************************************************

		sr_loder.c

		defalut.

		TIME LIST:
		CREATE	dreamfrank	2009-12-29 16:22:04

		Copyright (c)  SubzerZero Studio 2000-2009
***************************************************************************/

#include <global.h>

#define LOGO_FILENAME "logo.bin"

static int show_logo( void )
{
	FILE * fp = fopen( LOGO_FILENAME, "rb" );
	screen_set_mode( 320, 240, LCD_A8R8G8B8 );
	if( fp == NULL )
		return -1;
	fseek( fp, 0x38+8, SEEK_SET );
	fread( lcd_bufferui(), 320*240*4, 1, fp );
	fclose(fp);
	lcd_updateui();
	sys_delay(5000);
	return 0;
}

void app_main( void )
{
extern int main();
	show_logo();
	lcd_clearui(0);
	lcd_updateui();
	main();
	exit(0);
}
