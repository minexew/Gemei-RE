/* lowlevel.h
   This file is part of SoftRenderer.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef LOWLEVEL_H
#define LOWLEVEL_H

#include <sdl.h>

#define SCREEN_WIDTH	800
#define SCREEN_HEIGHT	600

void putpixel(SDL_Surface *surface, unsigned x, unsigned y, char red, char green, char blue)
{
	if ( (x>=SCREEN_WIDTH) || (y>=SCREEN_HEIGHT) )
		return;
	Uint32 pixel = SDL_MapRGB(surface->format, red, green, blue);
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to set */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        *p = pixel;
        break;

    case 2:
        *(Uint16 *)p = pixel;
        break;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
            p[0] = (pixel >> 16) & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = pixel & 0xff;
        } else {
            p[0] = pixel & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = (pixel >> 16) & 0xff;
        }
        break;

    case 4:
        *(Uint32 *)p = pixel;
        break;
    }
}

// Draw Line Beresenham's algorithm
void DrawLine(SDL_Surface *surface, unsigned sx, unsigned sy, unsigned ex, unsigned ey, char red=255, char green=255, char blue=255)
{
	int deltaX = ex - sx;
	int deltaY = ey - sy;

	int absDeltaX = abs(deltaX);
	int absDeltaY = abs(deltaY);

	int x = sx;
	int y = sy;

	int incX = ((deltaX) < 0 ? -1 : (deltaX) > 0 ? 1 : 0);
	int incY = ((deltaY) < 0 ? -1 : (deltaY) > 0 ? 1 : 0);

	if(absDeltaX >= absDeltaY)
	{
		int val = absDeltaY >> 1;

		for(int i = 0;i < absDeltaX;i++)
		{
			val += absDeltaY;
			if(val >= absDeltaX)
			{
				val -= absDeltaX;
				y += incY;
			}
			x += incX;
			putpixel(surface,x,y,red,green,blue);
		}
	}
	else
	{
		int val = absDeltaX >> 1;

		for(int i = 0;i < absDeltaY;i++)
		{
			val += absDeltaX;
			if(val >= absDeltaY)
			{
				val -= absDeltaY;
				x += incX;
			}
			y += incY;
			putpixel(surface, x,y,red,green,blue);
		}
	}
}

#endif