/* main.cpp
   This file is part of SoftRenderer.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdlib.h>
#include <math.h>
#include <vector>
#include "SDL.h"

#include "TriMesh.h"

#define SCREEN_WIDTH	800
#define SCREEN_HEIGHT	600


SDL_Surface *screen;

using namespace std;


CTriMesh box;
CTriMesh pyramid;
void CreateBox()
{
	// We first save vertices
	box.vertices.push_back(CPoint3D(-10,-10,-10));
	box.vertices.push_back(CPoint3D(-10,10 ,-10));
	box.vertices.push_back(CPoint3D(10 ,10 ,-10));
	box.vertices.push_back(CPoint3D(10,-10 ,-10));

	box.vertices.push_back(CPoint3D(-10,-10,10));
	box.vertices.push_back(CPoint3D(-10,10 ,10));
	box.vertices.push_back(CPoint3D(10 ,10 ,10));
	box.vertices.push_back(CPoint3D(10,-10 ,10));

	// Defien riangles by vertices (indexed method)
	box.AddTriangle(CTriangle(3,2,1,10,200,10));
	box.AddTriangle(CTriangle(1,0,3,10,200,10));

	box.AddTriangle(CTriangle(7,6,2,200,200,200));
	box.AddTriangle(CTriangle(2,3,7,200,200,200));

	box.AddTriangle(CTriangle(4,5,6,100,100,100));
	box.AddTriangle(CTriangle(6,7,4,100,100,100));

	box.AddTriangle(CTriangle(0,1,5,150,150,150));
	box.AddTriangle(CTriangle(5,4,0,150,150,150));

	box.AddTriangle(CTriangle(5,1,2,200,10,20));
	box.AddTriangle(CTriangle(2,6,5,200,10,20));

	box.AddTriangle(CTriangle(0,4,7,10,10,200));
	box.AddTriangle(CTriangle(7,3,0,10,10,200));
}

void CreatePyramid()
{
	// We first save vertices
	pyramid.vertices.push_back(CPoint3D(-10,-10,-10));
	pyramid.vertices.push_back(CPoint3D( 10,-10,-10));
	pyramid.vertices.push_back(CPoint3D(10 ,10 , 10));
	pyramid.vertices.push_back(CPoint3D(10,-10 ,-10));

	// Triangles use vertices (indexed method)
	pyramid.AddTriangle(CTriangle(3,2,1,10,200,10));
	pyramid.AddTriangle(CTriangle(1,0,3,10,200,10));

	pyramid.AddTriangle(CTriangle(7,6,2,200,200,200));
	pyramid.AddTriangle(CTriangle(2,3,7,200,200,200));

	pyramid.AddTriangle(CTriangle(4,5,6,100,100,100));
	pyramid.AddTriangle(CTriangle(6,7,4,100,100,100));

	pyramid.AddTriangle(CTriangle(0,1,5,150,150,150));
	pyramid.AddTriangle(CTriangle(5,4,0,150,150,150));

	pyramid.AddTriangle(CTriangle(5,1,2,200,10,20));
	pyramid.AddTriangle(CTriangle(2,6,5,200,10,20));

	pyramid.AddTriangle(CTriangle(0,4,7,10,10,200));
	pyramid.AddTriangle(CTriangle(7,3,0,10,10,200));
}



void render(bool backcull, bool wireframe)
{   
  //Clear screen
  SDL_FillRect(screen, NULL, 0);

  // Lock surface if needed
  if (SDL_MUSTLOCK(screen)) 
    if (SDL_LockSurface(screen) < 0) 
      return;

  // Ask SDL for the time in milliseconds
  // smooth animation is better
  unsigned long tick = SDL_GetTicks();
  static unsigned long lastTick = tick;
  static double rotX=0.0, rotY=0.0, rotZ=0.0;

  float secs = (tick-lastTick) * 0.001f;

  rotX += 20.0f * secs;
  rotY += 15.0f * secs;
  rotZ += 13.0f * secs;
  

  box.Rotate(rotX, rotY, rotZ);
  box.Render(screen,wireframe,backcull);

  lastTick = tick;


  // Unlock if needed
  if (SDL_MUSTLOCK(screen)) 
    SDL_UnlockSurface(screen);

  // Flip the new screen
  SDL_Flip(screen);
}


// Entry point
int main(int argc, char *argv[])
{
	bool backcull = true;
	bool wireframe = false;
	CreateBox();
  // Initialize SDL's subsystems - in this case, only video.
  if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) 
  {
    fprintf(stderr, "Unable to init SDL: %s\n", SDL_GetError());
    exit(1);
  }
  
  SDL_ShowCursor(SDL_DISABLE);

  // Register SDL_Quit to be called at exit; makes sure things are
  // cleaned up when we quit.
  atexit(SDL_Quit);
    
  // Attempt to create a 640x480 window with 32bit pixels.
  screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_FULLSCREEN|SDL_DOUBLEBUF|SDL_HWSURFACE);
  
  // If we fail, return error.
  if ( screen == NULL ) 
  {
    fprintf(stderr, "Unable to set SCREEN_WIDTHxSCREEN_HEIGHT video: %s\n", SDL_GetError());
    exit(1);
  }

  // Main loop: loop forever.
  while (1)
  {
    // Render stuff
    render(backcull,wireframe);

    // Poll for events, and handle the ones we care about.
    SDL_Event event;
    while (SDL_PollEvent(&event)) 
    {
      switch (event.type) 
      {
      case SDL_KEYDOWN:
		  if (event.key.keysym.sym == SDLK_UP)
			  backcull = !backcull;
		  if (event.key.keysym.sym == SDLK_DOWN)
			  wireframe = !wireframe;
        break;
      case SDL_KEYUP:
        // If escape is pressed, return (and thus, quit)
        if (event.key.keysym.sym == SDLK_a)
		{
		  SDL_ShowCursor(SDL_ENABLE);
          return 0;
		}
        break;
      case SDL_QUIT:
		SDL_ShowCursor(SDL_ENABLE);
		return(0);
      }
    }
  }
  return 0;
}
