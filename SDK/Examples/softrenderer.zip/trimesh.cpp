/* trimesh.h
   This file is part of SoftRenderer.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "TriMesh.h"
#include "lowlevel.h"
#include "math.h"


typedef struct {
	long	dims[2];				// Start and end position of the span
	float   dep[2];
} HSpan;
HSpan		spans[600];		// Horizontal spans
float  zBuffer[600][800];

long minY=599,maxY=1;

void span(CPoint3D v1, CPoint3D v2)
{
	CPoint3D* p1;
	CPoint3D* p2;

	if(v1.y >= v2.y - 0.0001 &&
	   v1.y <= v2.y + 0.0001) return;

	if (v1.y<v2.y)
	{
		p1 = &v1;
		p2 = &v2;
	}
	else
	{
		p2 = &v1;
		p1 = &v2;
	}

	float slopeX, x;

	x		= p1->x;
	float z		= p1->z;
	slopeX	= (p2->x - p1->x) / (p2->y - p1->y);
	float slopeZ  = (p2->z - p1->z) / (p2->y - p1->y);

	long fy = (long) p1->y;
	long ly = (long) p2->y;

	if(fy < 0) 
	{
		x += slopeX * (0 - fy);
		fy = 0;
	}

	if(fy < minY) minY = fy;
	if(ly > maxY) maxY = ly;

	// Scan convert the edge
	long sx;

	for(int i = fy; i < ly; i++) 
	{
		sx = (long)x;
		if(sx < spans[i].dims[0]) 
		{
			spans[i].dims[0] = sx;
			spans[i].dep[0] = z;
		}
		if(sx > spans[i].dims[1]) 
		{
			spans[i].dims[1] = sx;
			spans[i].dep[1] = z;
		}
		x += slopeX;
		z += slopeZ;
	}

}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CTriMesh::CTriMesh()
{

}

CTriMesh::~CTriMesh()
{

}

void CTriMesh::AddTriangle(CTriangle triangle)
{
	double temp1x = vertices[triangle.v1].x;
	double temp1y = vertices[triangle.v1].y;
	double temp1z = vertices[triangle.v1].z;

	double temp2x = vertices[triangle.v2].x;
	double temp2y = vertices[triangle.v2].y;
	double temp2z = vertices[triangle.v2].z;

	double temp3x = vertices[triangle.v3].x;
	double temp3y = vertices[triangle.v3].y;
	double temp3z = vertices[triangle.v3].z;

	// Calculate normal
	triangle.normal.x = (temp2y-temp1y)*(temp3z-temp2z)-(temp2z-temp1z)*(temp3y-temp2y);
	triangle.normal.y = (temp2z-temp1z)*(temp3x-temp2x)-(temp2x-temp1x)*(temp3z-temp2z);
	triangle.normal.z = (temp2x-temp1x)*(temp3y-temp2y)-(temp2y-temp1y)*(temp3x-temp2x);

	triangles.push_back(triangle);
}

void CTriMesh::Render(SDL_Surface *screen, bool wireframe, bool backcull, bool light)
{
	if (!wireframe)
	{
		//memcpy(zBuffer,NULL,sizeof(zBuffer));
		for (int i=0; i<600; i++)
			for (int j=0; j<800;j++)
				zBuffer[i][j]=100;
	}

  for(int i=0; i<triangles.size(); i++)
  {

	double temp1x = vertices[triangles[i].v1].x;
	double temp1y = vertices[triangles[i].v1].y;
	double temp1z = vertices[triangles[i].v1].z;

	double temp2x = vertices[triangles[i].v2].x;
	double temp2y = vertices[triangles[i].v2].y;
	double temp2z = vertices[triangles[i].v2].z;

	double temp3x = vertices[triangles[i].v3].x;
	double temp3y = vertices[triangles[i].v3].y;
	double temp3z = vertices[triangles[i].v3].z;

	double cosi = cos(angleY);
	double sini = sin(angleY);

	if (angleY!=0)
	{
		double temp = temp1x * cosi + temp1z * sini;
		temp1z =-temp1x * sini + temp1z * cosi;
		temp1x = temp;

		temp = temp2x * cosi + temp2z * sini;
		temp2z =-temp2x * sini + temp2z * cosi;
		temp2x = temp;

		temp = temp3x * cosi + temp3z * sini;
		temp3z =-temp3x * sini + temp3z * cosi;
		temp3x = temp;
	}
	if (angleX!=0)
	{
		double temp = temp1y * cosi - temp1z * sini;
		temp1z = temp1y * sini + temp1z * cosi;
		temp1y = temp;

		temp = temp2y * cosi - temp2z * sini;
		temp2z = temp2y * sini + temp2z * cosi;
		temp2y = temp;

		temp = temp3y * cosi - temp3z * sini;
		temp3z = temp3y * sini + temp3z * cosi;
		temp3y = temp;
	}
	if (angleZ!=0)
	{
		double temp = temp1x * cosi - temp1y * sini;
		temp1y = temp1x * sini + temp1y * cosi;
		temp1x = temp;

		temp = temp2x * cosi - temp2y * sini;
		temp2y = temp2x * sini + temp2y * cosi;
		temp2x = temp;

		temp = temp3x * cosi - temp3y * sini;
		temp3y = temp3x * sini + temp3y * cosi;
		temp3x = temp;
	}

	double distance =50;
	double angle = 300;

	temp1x = temp1x * (angle/(temp1z+distance));
	temp1y = temp1y * (angle/(temp1z+distance));

	temp2x = temp2x * (angle/(temp2z+distance));
	temp2y = temp2y * (angle/(temp2z+distance));

	temp3x = temp3x * (angle/(temp3z+distance));
	temp3y = temp3y * (angle/(temp3z+distance));



	if(wireframe)
	{
		if ( backcull && ((temp2x-temp1x)*(temp3y-temp2y)-(temp2y-temp1y)*(temp3x-temp2x)<0.0) ) 
			continue;

		DrawLine(screen,SCREEN_WIDTH/2 + temp1x, SCREEN_HEIGHT/2 + temp1y,
		SCREEN_WIDTH/2 + temp2x, SCREEN_HEIGHT/2 + temp2y);

		DrawLine(screen,SCREEN_WIDTH/2 + temp2x, SCREEN_HEIGHT/2 + temp2y,
		SCREEN_WIDTH/2 + temp3x, SCREEN_HEIGHT/2 + temp3y);

		DrawLine(screen,SCREEN_WIDTH/2 + temp1x, SCREEN_HEIGHT/2 + temp1y,
		SCREEN_WIDTH/2 + temp3x, SCREEN_HEIGHT/2 + temp3y);
	}
	else
	{
		if ( ((temp2x-temp1x)*(temp3y-temp2y)-(temp2y-temp1y)*(temp3x-temp2x)<0.0) ) 
			continue;
		CPoint3D v1(SCREEN_WIDTH/2+temp1x,SCREEN_HEIGHT/2+temp1y,temp1z);
		CPoint3D v2(SCREEN_WIDTH/2+temp2x,SCREEN_HEIGHT/2+temp2y,temp2z);
		CPoint3D v3(SCREEN_WIDTH/2+temp3x,SCREEN_HEIGHT/2+temp3y,temp3z);

		minY=1000,maxY=-1000;
		for(int ii = 0; ii < 600; ii++) 
		{
			spans[ii].dims[0] = 10000;
			spans[ii].dims[1] = -10000;
		}

		span(v1,v2);
		span(v2,v3);
		span(v1,v3);

		long x1, x2;

		for(int t = minY; t < maxY; t++) 
		{

			// Get the start and end points of the current span		
			x1 = spans[t].dims[0];
			x2 = spans[t].dims[1];

			if(x1 >= 800) continue;
			if(x2 < 0) continue;
			if(x1 < 0) {
				x1 = 0;
			}
			if(x2 >= 800) {
				x2 = 800 - 1;
			}

			// Render span
			for(int j = x1; j <= x2; j++) 
			{
				float depth = spans[t].dep[0]+(j-x1)*(spans[t].dep[1]-spans[t].dep[0])/(x2-x1);
				if(zBuffer[t][j] > depth)
				{
					zBuffer[t][j] = depth;
					if (light)
					{
						char bright= 0;
						putpixel(screen,j,t,triangles[i].red,triangles[i].green,triangles[i].blue);
					}
					else
						putpixel(screen,j,t,triangles[i].red,triangles[i].green,triangles[i].blue);
					
				}
			}
		}
	}
  }

}

void CTriMesh::Rotate(double xaxis, double yaxis, double zaxis)
{
	angleY = yaxis * 13.14159265 / 180.0;
	angleX = xaxis * 13.14159265 / 180.0;
	angleZ = zaxis * 13.14159265 / 180.0;
}

