/* trimesh.h
   This file is part of SoftRenderer.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#if !defined(AFX_TRIMESH_H__1093B27A_D529_4F25_924E_851130D8CDF7__INCLUDED_)
#define AFX_TRIMESH_H__1093B27A_D529_4F25_924E_851130D8CDF7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include "SDL.h"

class CPoint3D
{
public:
	CPoint3D(){ x=0;y=0;z=0; };
	CPoint3D(double _x, double _y, double _z){ x=_x;y=_y;z=_z; };
	double x,y,z;
};

class CTriangle
{
public:
	CTriangle(int _v1, int _v2, int _v3, char _red=255,char _green=255,char _blue=255)
	{ v1=_v1;v2=_v2;v3=_v3;red=_red;green=_green;blue=_blue;};
	int v1,v2,v3;
	char red,green,blue;
	CPoint3D normal;
};


class CTriMesh  
{
public:
	CTriMesh();
	virtual ~CTriMesh();

	void Rotate(double xaxis, double yaxis, double zaxis);
	void Render(SDL_Surface *screen, bool wireframe=true, bool backcull=true, bool light=false);
	void AddTriangle(CTriangle triangle);

	std::vector<CPoint3D> vertices;
	std::vector<CTriangle> triangles;

	double angleY;
	double angleX;
	double angleZ;

};

#endif // !defined(AFX_TRIMESH_H__1093B27A_D529_4F25_924E_851130D8CDF7__INCLUDED_)
